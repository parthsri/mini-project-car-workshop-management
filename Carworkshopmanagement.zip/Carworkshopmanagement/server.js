var http=require('http');
var express=require('express');
const app=express();
var path=require('path');
var bodyParser=require('body-parser');
var staticFolder=express.static(path.join(__dirname,"./public"));
app.use(staticFolder);
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

app.get("/",function(request,response){
    response.sendFile(path.join(__dirname,"./public/index"));
});

//const rout=require('./router')
// rout(app);

app.listen(9099);
console.log("server is running at port no 9099");
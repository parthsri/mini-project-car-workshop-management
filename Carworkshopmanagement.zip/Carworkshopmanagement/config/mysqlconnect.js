//dependency 
//connection of database
var mysql=require("mysql");

//define connection string
var connection=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"parth94524",
    database:"crud"
});
//error handler
connection.connect(function(err){
      if(err)
      throw err;
      console.log("Database connected");

});
 module.exports=connection;
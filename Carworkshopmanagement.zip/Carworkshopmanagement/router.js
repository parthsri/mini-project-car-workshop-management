'user strict';
var controller=require('./controllers/controller');
var 